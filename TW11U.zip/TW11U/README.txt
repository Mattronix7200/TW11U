To-W11Upgrade [TPM 2.0 Bypass Tool]
by KrzyGRU. WindowsBASE.pl (2022)
===================================

* Czym jest program To-W11Upgrade?
----------------------------------
Program jest małym narzędziem umożliwiającym przygotowanie gotowego nośnika instalacyjnego z systemem Windows 11 do instalacji tego systemu na niewspieranym sprzęcie. Program nie tworzy nośnika instalacyjnego, jeśli chcesz go uzyskać, w tym celu skorzystaj z programu Rufus lub Media Creation Tool. Poradnik dotyczący jego tworzenia, znajdziesz w bazie wiedzy na naszej stronie: https://windowsbase.pl

Aplikacja stworzona została na licencji Freeware, dzięki czemu każdy użytkownik serwisu może skorzystać z aplikacji bez opłat, ale również udostępnić go w niezmienionej formie osobom trzecim. Zabrania się modyfikowania aplikacji bez wiedzy autorów, oraz udostępniania zmienionej wersji w innym źródle niż ta opublikowana na oficjalnej stronie internetowej: https://windowsbase.pl lub w innym źródle za zgodą autorów. Autorzy aplikacji informują użytkownika, iż aplikacja wykorzystuje moduły, grafikę oraz inne pakiety wymagane do zbudowania tej aplikacji, które zostały oparte na licencjach Open-Source innych twórców. Autorzy aplikacji nie odpowiadają za błędy wynikające z nieprawidłowego procesu instalacji, użytkownik serwisu oraz aplikacji jest odpowiedzialny za wykorzystywanie aplikacji w celach edukacyjnych, hobbystycznych, własnych użytkowych oraz domowych, wszelka próba pobierania programu oraz udostępnianie go w serwisach odpłatnie bądź w innych źródłach jest niezgodne z prawem i może przynieść kosekwencje prawne.


* Czego potrzebuję aby uruchomić ten program?
---------------------------------------------
System Windows w dowolnej wersji bez żadnych modyfikacji. Program uruchamia się na silniku MSHTA oraz VBScript, więc jeśli nie posiadasz tych modułów, program się nie uruchomi. Poniżej szczegóły wymagań systemowych:

-System operacyjny: Windows 7 / Windows 8 / 8.1 / Windows 10 / Windows 11+
-Pamięć RAM: około 20 MB
-Pamięć dyskowa: około 10 MB
-Monitor o rozdzielczości co najmniej 1024x768
-Dostęp do internetu


* Antywirus wykrywa pliki programu jako zagrożenie. Czy to wirus?
-----------------------------------------------------------------

Aplikacja jest darmowa, i bezpieczna, dlatego nie musisz martwić się o bezpieczeństwo podczas instalacji. Zastrzegamy jednak, że niektóre programy antywirusowe mogą wykryć naszą aplikację jako zagrożenie, prosimy wtedy nie sugerować się informacją o wykrytym zagrożeniu, lecz zignorować ten fakt oraz dodać aplikację jako wyjątek w programie antywirusowym. W razie wątpliwości, zajrzyj do naszego kodu na Githubie: https://github.com/Mattronix7200

* Jak uruchomić aplikację?
--------------------------

Dwukrotnie naciśnij przyciskiem myszy na aplikację o nazwie: "TW11U.exe"

Więcej informacji na temat naszej aplikacji oraz pomoc techniczną uzyskasz na naszej stronie internetowej: https://windowsbase.pl

Uwaga! Pamiętaj aby nie usuwać plików programu znajdujących się w katalogu o nazwie "Files", ich usunięcie spowoduje nieprawidłowe działanie aplikacji.

===================================
Zmiany w wersji programu:

V.1.0.1: 
[+] Zaktualizowano strukturę plików programu
[+] Zaktualizowano wygląd aplikacji
[+] Naprawiono problem podczas uruchamiania skryptów.

V.1.0.0: 
Wydano aplikację do użytku.
